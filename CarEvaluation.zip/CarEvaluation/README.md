# First, install all packages according to these imports in the main.py:

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import warnings
from matplotlib.colors import ListedColormap
from matplotlib.ticker import MaxNLocator
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.metrics import mean_absolute_error, accuracy_score
from random import randrange
from sklearn.tree import DecisionTreeClassifier
from collections import Counter

# RandomForest.py created as a class, hence it must be imported into main.py:

import RandomForest as rf

# RandomForests can be implemented in this way in main.py:

# Reading data first 
X_train = pd.read_csv('data/cancer_X_train.csv')
y_train = pd.read_csv('data/cancer_y_train.csv')
X_test = pd.read_csv('data/cancer_X_test.csv')
y_test = pd.read_csv('data/cancer_y_test.csv')

# Applying RandomForest
forest = rf.RandomForest(n_estimators=50, max_depth=6, random_state=1)
forest.fit(X_train, y_train)
y_pred = forest.predict(X_test)
score = accuracy_score(y_test, y_pred)
print("The accuracy is: ", score)

# You will be able to specify these parameters (note: they set to standard values):
n_estimators=100
criterion='gini'
max_features=None
max_depth=None
random_state=None
