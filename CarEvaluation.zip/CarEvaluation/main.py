import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import warnings
from matplotlib.colors import ListedColormap
from matplotlib.ticker import MaxNLocator
from sklearn.ensemble import RandomForestClassifier
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.metrics import mean_absolute_error, accuracy_score
import importlib
import RandomForest as rf

from sklearn.preprocessing import LabelEncoder

import RandomForest as rf

# reading data
X_train = pd.read_csv('data/car_X_train.csv')
y_train = pd.read_csv('data/car_y_train.csv')
X_test = pd.read_csv('data/car_X_test.csv')
y_test = pd.read_csv('data/car_y_test.csv')

######################
# DATA PREPROCESSING #
######################

# Dealing with missing values - uncomment the 4 lines above to make sure that there is no any missing value
# print(X_train.isnull().sum())
# print(y_train.isnull().sum())
# print(X_test.isnull().sum())
# print(y_test.isnull().sum())

# uncomment to print unique values of each feature
# print('unique features of buying: ', X_train['buying'].unique())
# print('unique features of maint: ', X_train['maint'].unique())
# print('unique features of doors: ', X_train['doors'].unique())
# print('unique features of persons: ', X_train['persons'].unique())
# print('unique features of lug_boot: ', X_train['lug_boot'].unique())
# print('unique features of safety: ', X_train['safety'].unique())

# using the info we got above, perform mapping of ordinal features
buying_mapping = {'low': 1, 'med': 2, 'high': 3, 'vhigh': 4}
maint_mapping = {'low': 1, 'med': 2, 'high': 3, 'vhigh': 4}
doors_mapping = {'2': 2, '3': 3, '4': 4, '5more': 5}
persons_mapping = {'2': 2, '4': 4, 'more': 5}
lug_boot_mapping = {'small': 1, 'med': 2, 'big': 3}
safety_mapping = {'low': 1, 'med': 2, 'high': 3}

x_list = [X_train, X_test]
f_list = ['buying', 'maint', 'doors', 'persons', 'lug_boot', 'safety']
m_list = [buying_mapping, maint_mapping, doors_mapping, persons_mapping, lug_boot_mapping, safety_mapping]

for x in x_list:
    for i in range(len(f_list)):
        x[f_list[i]] = x[f_list[i]].map(m_list[i])

# Similarly, for labels encoding
# uncomment the line below to print all class labels
# print('labels: ', y_train['class'].unique())

# using the info we got above, perform mapping of ordinal features
class_mapping = {'unacc': 0, 'acc': 1, 'good': 2, 'vgood': 3}
y_list = [y_train, y_test]

for y in y_list:
    y['class'] = y['class'].map(class_mapping)

# Applying Random Forests 10 times just to see how we perform
scorelist = list()
iterations = list()
for i in range(10):
    forest = rf.RandomForest(random_state=1)
    forest.fit(X_train, y_train)
    y_pred = forest.predict(X_test)
    score = accuracy_score(y_test, y_pred)
    scorelist.append(score)
    iterations.append(i)

# plotting the result
plt.plot(iterations, scorelist)
plt.xlabel('iretations = 10')
plt.xticks(iterations)
plt.ylabel('accuracy score')
plt.title('Accuracy performance')
plt.show()

# Mapping the "5more"

# # Case-1: 5more: 5
# doors_mapping_5 = {2: 2, 3: 3, 4: 4, 5: 5}
# X_train['doors'] = X_train['doors'].map(doors_mapping_5)
# X_test['doors'] = X_test['doors'].map(doors_mapping_5)
# scorelist_5 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_5.append(score)
#
# mean_5 = np.mean(scorelist_5)
#
# # Case-1: 5more: 6
# doors_mapping_6 = {2: 2, 3: 3, 4: 4, 5: 6}
# X_train['doors'] = X_train['doors'].map(doors_mapping_6)
# X_test['doors'] = X_test['doors'].map(doors_mapping_6)
# scorelist_6 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_6.append(score)
#
# mean_6 = np.mean(scorelist_6)
#
# # Case-3: 5more: 7
# doors_mapping_7 = {2: 2, 3: 3, 4: 4, 6: 7}
# X_train['doors'] = X_train['doors'].map(doors_mapping_7)
# X_test['doors'] = X_test['doors'].map(doors_mapping_7)
# scorelist_7 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_7.append(score)
#
# mean_7 = np.mean(scorelist_6)
#
# # Case-4: 5more: 8
# doors_mapping_8 = {2: 2, 3: 3, 4: 4, 7: 8}
# X_train['doors'] = X_train['doors'].map(doors_mapping_8)
# X_test['doors'] = X_test['doors'].map(doors_mapping_8)
# scorelist_8 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_8.append(score)
#
# mean_8 = np.mean(scorelist_8)
#
# # Case-5: 5more: 9
# doors_mapping_9 = {2: 2, 3: 3, 4: 4, 8: 9}
# X_train['doors'] = X_train['doors'].map(doors_mapping_9)
# X_test['doors'] = X_test['doors'].map(doors_mapping_9)
# scorelist_9 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_9.append(score)
#
# mean_9 = np.mean(scorelist_9)
#
# mean_scores = [mean_5, mean_6, mean_7, mean_8, mean_9]
# values = [5,6,7,8,9]
#
# # plotting comparison
# plt.bar(values, mean_scores)
# plt.xticks(values)
# plt.ylim(bottom=0.94)
# plt.xlabel("Mapping to")
# plt.ylabel('Accuracy Score')
# plt.title('Choosing the right mapping value')
# plt.legend()
# plt.show()


# Mapping the "more" of persons

# # # Case-1: 5more: 5
# persons_mapping_5 = {2: 2, 4: 4, 5: 5}
# X_train['persons'] = X_train['persons'].map(persons_mapping_5)
# X_test['persons'] = X_test['persons'].map(persons_mapping_5)
# scorelist_5 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_5.append(score)
#
# mean_5 = np.mean(scorelist_5)
#
# # # Case-2: 5more: 7
# persons_mapping_7 = {2: 2, 4: 4, 5: 7}
# X_train['persons'] = X_train['persons'].map(persons_mapping_7)
# X_test['persons'] = X_test['persons'].map(persons_mapping_7)
# scorelist_7 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_7.append(score)
#
# mean_7 = np.mean(scorelist_7)
#
# # # Case-3: 5more: 7
# persons_mapping_9 = {2: 2, 4: 4, 7: 9}
# X_train['persons'] = X_train['persons'].map(persons_mapping_9)
# X_test['persons'] = X_test['persons'].map(persons_mapping_9)
# scorelist_9 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_9.append(score)
#
# mean_9 = np.mean(scorelist_9)
#
# # # Case-4: 5more: 12
# persons_mapping_12 = {2: 2, 4: 4, 9: 12}
# X_train['persons'] = X_train['persons'].map(persons_mapping_12)
# X_test['persons'] = X_test['persons'].map(persons_mapping_12)
# scorelist_12 = list()
#
# for i in range(10):
#     forest = rf.RandomForest(random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_12.append(score)
#
# mean_12 = np.mean(scorelist_12)
#
# values = [5,7,9,12]
# mean_scores = [mean_5,mean_7,mean_9,mean_12]
#
# # plotting comparison
# plt.bar(values, mean_scores)
# plt.xticks(values)
# plt.ylim(bottom=0.9)
# plt.xlabel("Mapping to")
# plt.ylabel('mean Accuracy Score of 10 samples')
# plt.title('Choosing the right mapping value')
# plt.show()

#########################################################################################
# How the number of samples (aka n_estimators) affects the performance of the algorithm.#
#########################################################################################

# # storing all the scores and corresponding n_estimator arguments in the lists
# n_estimators_score = list()
# n_estimators_number = list()
#
# # Calculating the accuracy scores using Random Forests
# for i in range(1,201,2):
#     forest = rf.RandomForest(n_estimators=i, random_state=1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     n_estimators_score.append(score)
#     n_estimators_number.append(i)
#
# # # Plotting the result
# fig, ax = plt.subplots()
# ax.plot(n_estimators_number, n_estimators_score)
# ax.set(xlabel="n_estimators", ylabel="Accuracy Score", title=" how number of samples affects performance")
# fig.savefig("n_estimators_performance.png")
# plt.show()

##########################################################################
# How the maximum depth number affects the performance of the algorithm. #
##########################################################################

# # storing all the scores and corresponding max_depth arguments in the lists
# max_depth_score = list()
# max_depth_number = list()
#
# # Calculating the accuracy scores using Random Forests
# for i in range(1,60):
#     forest = rf.RandomForest(n_estimators=30, max_depth=i, random_state = 1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     max_depth_score.append(score)
#     max_depth_number.append(i)
#
# # Plotting the result
# fig, ax = plt.subplots()
# ax.plot(max_depth_number,max_depth_score)
# ax.set(xlabel="max_depth", ylabel="Accuracy Score", title=" how max depth number affects the accuracy performance")
# ax.xaxis.set_major_locator(MaxNLocator(integer=True))
# fig.savefig("max_depth_performance.png")
# plt.show()

#############################################################################
# How the maximum features number affects the performance of the algorithm. #
#############################################################################

# # storing all the scores and corresponding max_features arguments in the lists
# max_features_score = list()
# max_features_number = list()
# max_features_score_mean = list()
# # Calculating the accuracy scores using Random Forests
#
# for i in range(1,7):
#     for iteration in range(10):
#         forest = rf.RandomForest(n_estimators=30, max_features=i, random_state = 1)
#         forest.fit(X_train, y_train)
#         y_pred = forest.predict(X_test)
#         score = accuracy_score(y_test, y_pred)
#         max_features_score.append(score)
#     max_features_score_mean.append(np.mean(max_features_score))
#     max_features_number.append(i)
#
# # Plotting the result
# fig, ax = plt.subplots()
# ax.plot(max_features_number,max_features_score_mean)
# ax.set(xlabel="max_features", ylabel="Accuracy Score", title=" how max features number affects the accuracy performance")
# ax.xaxis.set_major_locator(MaxNLocator(integer=True))
# fig.savefig("max_features_performance.png")
# plt.show()