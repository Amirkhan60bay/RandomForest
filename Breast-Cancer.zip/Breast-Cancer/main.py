import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import warnings
from matplotlib.colors import ListedColormap
from matplotlib.ticker import MaxNLocator
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel
from sklearn.metrics import mean_absolute_error, accuracy_score
import RandomForest as rf

# READING DATA
X_train = pd.read_csv('data/cancer_X_train.csv')
y_train = pd.read_csv('data/cancer_y_train.csv')
X_test = pd.read_csv('data/cancer_X_test.csv')
y_test = pd.read_csv('data/cancer_y_test.csv')

# TESTING
forest = rf.RandomForest(n_estimators=50, max_depth=6, random_state=1)
forest.fit(X_train, y_train)
y_pred = forest.predict(X_test)
score = accuracy_score(y_test, y_pred)
print("The accuracy is: ", score)

######################
# DATA PREPROCESSING #
######################

# # Dealing with mising data
# # By uncommenting the print statements below, it can be seen that there is no missing data, so there is no need to deal with that
# print(X_train.isnull().sum())
# print(y_train.isnull().sum())
# print(X_test.isnull().sum())
# print(y_test.isnull().sum())

#########################################################################################
# How the number of samples (aka n_estimators) affects the performance of the algorithm.#
#########################################################################################

# # storing all the scores and corresponding n_estimator arguments in the lists
# n_estimators_score = list()
# n_estimators_number = list()

# # Calculating the accuracy scores using Random Forests
# for i in range(1,150):
#     forest = rf.RandomForest(n_estimators = i, random_state = 1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     n_estimators_score.append(score)
#     n_estimators_number.append(i)

# # Plotting the result
# fig, ax = plt.subplots()
# ax.plot(n_estimators_number,n_estimators_score)
# ax.set(xlabel="n_estimators", ylabel="Accuracy Score", title=" how number of samples affects performance")
# fig.savefig("n_estimators_performance.png")
# plt.show()

##########################################################################
# How the maximum depth number affects the performance of the algorithm. #
##########################################################################

# # storing all the scores and corresponding max_depth arguments in the lists
# max_depth_score = list()
# max_depth_number = list()
#
# # Calculating the accuracy scores using Random Forests
# for i in range(1,20):
#     forest = rf.RandomForest(n_estimators=50, max_depth=i, random_state = 1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     max_depth_score.append(score)
#     max_depth_number.append(i)
#
# # Plotting the result
# fig, ax = plt.subplots()
# ax.plot(max_depth_number,max_depth_score)
# ax.set(xlabel="max_depth", ylabel="Accuracy Score", title=" how max depth number affects the accuracy performance")
# ax.xaxis.set_major_locator(MaxNLocator(integer=True))
# fig.savefig("max_depth_performance.png")
# plt.show()

#############################################################################
# How the maximum features number affects the performance of the algorithm. #
#############################################################################

# # storing all the scores and corresponding max_features arguments in the lists
# max_features_score = list()
# max_features_number = list()
#
# # Calculating the accuracy scores using Random Forests
# for i in range(1,30):
#     forest = rf.RandomForest(n_estimators=50, max_features=i, random_state = 1)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     max_features_score.append(score)
#     max_features_number.append(i)
#
# # Plotting the result
# fig, ax = plt.subplots()
# ax.plot(max_features_number,max_features_score)
# ax.set(xlabel="max_features", ylabel="Accuracy Score", title=" how max features number affects the accuracy performance")
# ax.xaxis.set_major_locator(MaxNLocator(integer=True))
# fig.savefig("max_features_performance.png")
# plt.show()

#####################
# FEATURE SELECTION #
#####################

# # Find the most important features
# feat_labels = X_train.columns[1:]
# clf = ExtraTreesClassifier(n_estimators=300)
# clf = clf.fit(X_train, np.ravel(y_train))
# importances = clf.feature_importances_
# indices = np.argsort(importances)[::1]

# # plotting
# fig, ax = plt.subplots()
# plt.title('Feature importance')
# plt.bar(range(X_train.shape[1]), importances[indices], align='center')
# plt.xticks(range(X_train.shape[1]), feat_labels[indices-1], rotation=90)
# plt.xlim([-1, X_train.shape[1]])
# plt.tight_layout()
# fig.savefig("features_improtances.png")
# plt.show()

# # Selecting Features from Model
# model = SelectFromModel(clf, prefit=True)
# X_new = model.transform(X_train)
# X_new = pd.DataFrame(X_new)
# X_test_new = model.transform(X_test)
# X_test_new = pd.DataFrame(X_test_new)
# print("Number of features selected:", X_new.shape[1])

# # Compare the models 10 times
# scorelist_new = list()
# scorelist_old = list()
# comparisons = list()
# for i in range(10):
#     forest_new = rf.RandomForest(n_estimators=50, random_state=1, max_depth=6)
#     forest_new.fit(X_new, y_train)
#     y_pred_new = forest_new.predict(X_test_new)
#     score_new = accuracy_score(y_test, y_pred_new)
#     scorelist_new.append(score_new)
#
#     forest = rf.RandomForest(n_estimators=50, random_state=1, max_depth=6)
#     forest.fit(X_train, y_train)
#     y_pred = forest.predict(X_test)
#     score = accuracy_score(y_test, y_pred)
#     scorelist_old.append(score)
#
#     comparisons.append(i+1)
# print(scorelist_new, scorelist_old)
#
# #plotting comparison
# plt.plot(comparisons, scorelist_new, label='with less features')
# plt.plot(comparisons, scorelist_old, label='all features')
# plt.xlabel('comparison no.')
# plt.ylabel('accuracy score')
# plt.title('What if we drop less significant features?')
# plt.legend()
# plt.show()