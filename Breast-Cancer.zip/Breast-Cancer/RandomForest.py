import numpy as np
import pandas as pd
from random import randrange
from sklearn.tree import DecisionTreeClassifier
from collections import Counter

def subsample(dataset, size):
    sample = list()
    n_sample = round(len(dataset) * size)
    while len(sample) < n_sample:
        index = randrange(len(dataset))
        sample.append(dataset[index])
    return sample


def aggregate_majority(predictions):
    predictions_df = pd.DataFrame(predictions)
    y_pred = list()
    for column in predictions_df.columns:
        prediction = Counter(predictions_df[column])
        prediction = prediction.most_common(1)[0][0]
        y_pred.append(prediction)
    y_pred = pd.DataFrame(y_pred)
    return y_pred


class RandomForest(object):
    def __init__(self, n_estimators=100, criterion='gini', max_features=None, max_depth=None, random_state=None):
        self.forest__ = list()
        self.n_estimators = n_estimators
        self.criterion = criterion
        self.max_features = max_features
        self.max_depth = max_depth
        self.random_state = random_state

    def fit(self, X, y):
        Xy_merged_df = X
        Xy_merged_df['Label'] = y
        Xy_merged_list = Xy_merged_df.to_numpy()
        random_forest = list()
        for i in range(self.n_estimators):
            Xy_sample = subsample(Xy_merged_list, 1)
            Xy_sample = pd.DataFrame(Xy_sample, columns=Xy_merged_df.columns)
            y_sample = Xy_sample['Label']
            X_sample = Xy_sample.drop(columns=['Label'])
            dtree = DecisionTreeClassifier(criterion=self.criterion, max_features=self.max_features,
                                           max_depth=self.max_depth, random_state=self.random_state)
            dtree.fit(X_sample, np.ravel(y_sample))
            random_forest.append(dtree)
        self.forest__ = random_forest
        return self

    def predict(self, X):
        predictions = list()
        for tree in self.forest__:
            y_pred = tree.predict(X)
            predictions.append(y_pred)
        return aggregate_majority(predictions)